﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el monto: ");
        double monto = Convert.ToDouble(Console.ReadLine());
        double descuento = 0;

        if (monto > 100)
        {
            descuento = monto * 0.10;
        }
        else
        {
            descuento = monto * 0.02;
        }

        double montoConDescuento = monto - descuento;

        Console.WriteLine("El descuento es: " + descuento);
        Console.WriteLine("El monto después del descuento es: " + montoConDescuento);
    }
}
