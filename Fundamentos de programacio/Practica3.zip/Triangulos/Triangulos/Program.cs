﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangulos
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Escribe el valor del lado a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Escribe el valor del lado b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Escribe el valor del lado c: ");
            int c = Convert.ToInt32(Console.ReadLine());

            if (a == b && b == c)
            {
                Console.WriteLine("El triangulo es equilatero");
            }
            else if (a == b || b == c || a == c)
            {
                Console.WriteLine("El triangulo es isoceles");
            }
            else 
            {
                Console.WriteLine("El triangulo es escaleno.");
            }

        }
    }
}
