﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajador
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Escribe las horas trabajadas: ");
            int horastrabajadas = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Introduce la tarifa por hora: ");
            double tarifa = Convert.ToDouble(Console.ReadLine());

            double salario;
              if (horastrabajadas > 40) 
              {
                int horasExtra = horastrabajadas - 40;
                salario = (40 * tarifa) + (horasExtra * tarifa * 1.5);
              }
              else 
              {
                salario = horastrabajadas * tarifa;
              }
            Console.WriteLine("El salario del trabajdor es: " + salario);
        }
    }
}
