﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el sueldo del trabajador: ");
        double sueldo = Convert.ToDouble(Console.ReadLine());
        double descuento = 0;

        if (sueldo <= 1000)
        {
            descuento = sueldo * 0.10;
        }
        else if (sueldo <= 2000)
        {
            descuento = 1000 * 0.10 + (sueldo - 1000) * 0.05;
        }
        else
        {
            descuento = 1000 * 0.10 + 1000 * 0.05 + (sueldo - 2000) * 0.03;
        }

        double sueldoNeto = sueldo - descuento;

        Console.WriteLine("El descuento es: " + descuento);
        Console.WriteLine("El sueldo neto es: " + sueldoNeto);
    }
}
