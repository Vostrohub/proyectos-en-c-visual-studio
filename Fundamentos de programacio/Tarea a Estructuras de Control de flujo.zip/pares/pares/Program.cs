﻿using System;

class Program
{
    static void Main()
    {
        for (int i = 20; i <= 200; i++)
        {
            if (i % 2 == 0)
            {
                Console.WriteLine(i);
            }
        }
    }
}
