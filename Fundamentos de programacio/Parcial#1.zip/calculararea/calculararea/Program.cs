﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculararea
{
    internal class Program
    {
        static void Main()
        {
            double radio = 2.50;
            double area = Math.PI * radio * radio;
            Console.WriteLine("El área del círculo es: " + area + " cm²");
        }
    }
}
