﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caraocruz
{
    internal class Program
    {
        static void Main()
        {
            Random rand = new Random();

            int moneda = rand.Next(2);

            string resultado = moneda == 0 ? "Cara" : "Cruz";

            Console.WriteLine(resultado);

        }
    }
}
