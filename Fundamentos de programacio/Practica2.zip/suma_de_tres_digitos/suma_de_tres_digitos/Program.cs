﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace suma_de_tres_digitos
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Escribe el numero de tres digitos");
            string input = Console.ReadLine();
            if (input.Length == 3)
            {
                int digit1 = int.Parse(input[0].ToString());
                int digit2 = int.Parse(input[1].ToString());
                int digit3 = int.Parse(input[2].ToString());

                int sum = digit1 + digit2 + digit3;
                Console.WriteLine($"El resultado de la suma de los digitos es: {sum}");

            }
            else
                Console.WriteLine("El numero ingresado no tiene tres digitos.");
        }
    }
}
