﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calcular_edades
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int edad1 = 12;
            int edad2 = 13;
            int edad3 = 14;

            int suma = edad1 + edad2 + edad3;
            Console.WriteLine("La suma de las edades es: "+ suma);

            double promedio = suma / 3.0;
            Console.WriteLine("El promedio de las edades es: " + promedio);

            int maxima = Math.Max(Math.Max(edad1, edad2), edad3);
            int minima = Math.Min(Math.Min(edad1, edad2), edad3);
            Console.WriteLine("La edad maxima es: " + maxima);
            Console.WriteLine("La edad minima es: " + minima);


        }
    }
}
