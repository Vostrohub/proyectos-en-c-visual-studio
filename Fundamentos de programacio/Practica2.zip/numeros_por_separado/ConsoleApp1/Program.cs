﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace numero_por_separado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero de dos digitos");
            string numero = Console.ReadLine();
            Console.Clear();

            Console.WriteLine("El primer digito es el siguiente:" + numero[0]);

            Console.WriteLine("El segundo digito es el siguiente:" +
                numero[1]);

        }
    }
}
/*
 * un programa que pongas ambos digitos dados por el usuario y 
 * muestre cada uno por separado*/