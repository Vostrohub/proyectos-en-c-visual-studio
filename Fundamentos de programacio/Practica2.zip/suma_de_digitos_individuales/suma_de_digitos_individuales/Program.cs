﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace suma_de_digitos_individuales
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Escribe el numero de dos digitos: ");
            string input = Console.ReadLine();
            if (input.Length == 2)
            {
                int digit1 = int.Parse(input[0].ToString());
                int digit2 = int.Parse(input[1].ToString());

                int sum = digit1 + digit2;
                Console.WriteLine($"El resultado de la suma de los digitos es: {sum}");
            }
            else
            
                Console.WriteLine("El número ingresado no tiene dos dígitos.");
        }
    }
}
