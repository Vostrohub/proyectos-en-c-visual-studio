﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4_numeros_por_separado
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Ingrese el numero de cuatro digitos");
            string numero = Console.ReadLine();
            if (numero.Length != 4)
            {

                Console.WriteLine("El numero ingresado no tiene cuatro digitos");

            }
            else
            {
            Console.WriteLine("El primer digito es el siguiente: "  + numero[0]);
            Console.WriteLine("El segundo digito es el siguiente: " + numero[1]);
            Console.WriteLine("El tercer digito es el siguiente: "  + numero[2]);
            Console.WriteLine("El cuarto digito es el siguiente: "  + numero[3]);
            }
        }
    }
}
